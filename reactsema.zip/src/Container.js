import React, {Component} from 'react';
import { Container} from 'semantic-ui-react';




class ContainerKlasse extends Component {


    render() {

        return(

            <div>   
                {/*Hier habe ich drei Container in einem div, mit % angaben um das Design flexibel zu halten  */}
                <div style={{widht: "100%", textAlign: "center"}}>
                  {/*draggable true, damit der Cursor sichtbar ist, der in css festgelegt*/}
                  <Container className="drago" draggable style={{width:"33%", float: "left", backgroundColor:"orange", height: 250, 
                    position: "absolute"}} 
                  >
                  Left Aligned
                  </Container>

                  <Container style={{width:"33%", float: "left"}} >
                  Center Aligned
                  </Container>
                  <Container style={{width:"33%", float: "right"}}>
                  Right Aligned
                  </Container>
                  </div>

            </div>

        );
    }
}

export default ContainerKlasse;

