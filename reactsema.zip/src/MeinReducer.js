import {initialState} from './MeinStore';

import {loginUser} from './FirebaseLoggin';

 

export const reducer = (state = initialState, action) => {

    switch(action.type) {

        case "istImSystem": 
        
            return {

             

                ...state, 
                //istEingeloggt: alert("hallo"),
                istEingeloggt: "blue",
                fireStart: loginUser()
               
                
            };

        case "istNichtImSystem": 

            return {
                ...state,
                isteingeloggt: false,


                    
                };

            

        default:

            return state

    }
}