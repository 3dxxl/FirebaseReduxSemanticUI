
import React, { Component } from 'react';

export class Hauptseite  extends Component {


    render() {
        return (

            <div>
            <h2>Du bist eingeloggt, das ist die HauptSeite</h2>

           </div>
            
        );
    }
}

export default Hauptseite;

