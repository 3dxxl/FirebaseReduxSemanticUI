import {createStore, applyMiddleware, compose} from 'redux';

import thunk from 'redux-thunk';

import {reducer} from './MeinReducer';

export const initialState = {

    istEingeloggt: "red",
    fireStart:"",
    istAusgeloggt:false,
    grad: 0.00,
};




//wichtig: zuerst der reducer dann der initialState = createStore(initialState, reducer, ...)
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
export const store = createStore(reducer, initialState, composeEnhancers(applyMiddleware(thunk) ) )

